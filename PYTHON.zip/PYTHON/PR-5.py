import pandas as pd 

data = {
    "name" : ["nagpur", "saoner", "kelwad"],
    "age" : [18,20,19],
    "city" : ["yash","anuj","yogi"]
}

df = pd.DataFrame(data)
send = df.to_excel("T:\PYTHON\dummy.xlsx", index = False , sheet_name="yogi")
print("\n Written Sucessfully")
print("\n")



try : 
    read7 = pd.read_excel("dummy.xlsx")
    print("The data read from the Excel file is : \n")
    print(read7)

except :
    print("File not found")
