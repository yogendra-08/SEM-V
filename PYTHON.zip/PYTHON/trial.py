import numpy 
from scipy import integrate

def my_function(x):
    return x**2 
res=integrate.quad(my_function, 0, 1)
print(res)


