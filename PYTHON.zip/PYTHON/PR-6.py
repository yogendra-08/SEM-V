import numpy as np 
from scipy import integrate


val1 = int(input("Enter the first value : "))
val2 = int(input("Enter the second value : "))

def f(x):
    return x ** 2

result = integrate.quad(f, val1, val2)

print("result = ", result)

