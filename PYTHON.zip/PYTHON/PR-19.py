import string 

str = " "
print("\nEntered string is:", str)

x = str.isspace()
print("\nString contains only spaces.", x,"\n")

str = "\n\t"

y = all( ch in string.whitespace for ch in str )
print("String contains only whitespaces.", y,"\n")

print(repr(string.whitespace))