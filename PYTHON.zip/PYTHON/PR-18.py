import string 

str = "Hello Trushna"
print("\nEntered string is:", str)

x = str.upper()
print("\nUppercase of the string is:", x)

y = str.lower()
print("\nLowercase of the string is:", y,"\n")

