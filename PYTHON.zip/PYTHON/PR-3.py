import pandas as pd 

data = {
    "name" : ["yogi", "yash", "prathmesh", "parag", "gaurav", "anuj", "om"],
    "age" : [25, 30, 22, None, 35, 27, 24],
    "city" : ["delhi", "mumbai", "pune", "bangalore", "hyderabad", "chennai", "kolkata"],
    "salary" : [50000, 60000, 45000, 70000, 80000, 55000, 48000]
}

df = pd.DataFrame(data)

print("Original DataFrame : \n")
print(df)
print("\n ------------------ \n")

df_drop = df.dropna()
print("DataFrame after dropping rows with NaN values : \n")
print(df_drop)
print("\n ------------------ \n")

df_fill = df.fillna(
    {
        "name" : "unknown",
        "age" : 55 ,
        "city" : "unknown",
        "salary" : 60000

    }
)

print("DataFrame after filling NaN values : \n")
print(df_fill)

