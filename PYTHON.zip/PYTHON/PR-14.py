import tkinter as tk
import time

root = tk.Tk()
root.title("Digital Clock")
root.geometry("250x120")
root.resizable(False, False)
root.configure(bg="black")

def update_clock():
    label.config(text=time.strftime("%H:%M:%S"))
    label.after(1000, update_clock)

def update_date():
    date_label.config(text=time.strftime("%Y-%m-%d"))
    date_label.after(86400000, update_date)

label = tk.Label(root, bg="black", fg="white")
label.pack(pady=5)

date_label = tk.Label(root, bg="black", fg="white")
date_label.pack()

update_clock()
update_date()
root.mainloop()
