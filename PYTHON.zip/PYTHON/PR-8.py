import numpy as np 
from scipy import stats as st 
import statistics

data = [1,2,3,4,5,6,7,8,9,10]

print("\n")
print("original")
print(data)
print("\n")

print("Mean : ", np.mean(data))
print("Median : ", np.median(data))

mode  = st.mode(data, keepdims=True)
print("Mode:", mode.mode[0], " (Count:", mode.count[0], ")")

# it also sorts the data in ascending order befor calvulating the midean