import string 

str_t = "2307004"

x = str_t.isdigit()

if x:
    print("\nString contains only digits.", x)

else:
    print("\nString contains characters and numbers.", x)

