import tkinter as tk
from tkinter import messagebox

# Functions
def calculate():
    try:
        result = eval(entry_var.get())
        entry_var.set(str(result))
    except:
        messagebox.showerror("Error", "Invalid Expression")
        entry_var.set("")

def clear_one():
    entry_var.set(entry_var.get()[:-1])

def clear_all():
    entry_var.set("")

def press(char):
    entry_var.set(entry_var.get() + str(char))

# Main window
root = tk.Tk()
root.title("Simple Calculator")
root.geometry("340x320")
root.resizable(0, 0)

# Entry widget
entry_var = tk.StringVar()
entry = tk.Entry(root, textvariable=entry_var, font=("Arial", 20), justify="right")
entry.grid(row=0, column=0, columnspan=4, ipadx=8, ipady=15, padx=10, pady=10, sticky="nsew")

# Buttons layout (only char, row, col)
buttons = [
    ("AC", 1, 0), ("/", 1, 2), ("*", 1, 3),
    ("7", 2, 0), ("8", 2, 1), ("9", 2, 2), ("-", 2, 3),
    ("4", 3, 0), ("5", 3, 1), ("6", 3, 2), ("+", 3, 3),
    ("1", 4, 0), ("2", 4, 1), ("3", 4, 2), ("=", 4, 3),
    ("C", 5, 0), ("0", 5, 1), (".", 5, 2)
]

# Create buttons
for (char, r, c) in buttons:
    # Default span
    cs, rs = 1, 1  

    # Special cases
    if char == "AC":
        cs = 2
    if char == "=":
        rs = 2

    # Button color
    color = "orange" if char in ["AC", "C", "="] else "gray"

    # Button command
    if char == "AC":
        command = clear_all
    elif char == "C":
        command = clear_one
    elif char == "=":
        command = calculate
    else:
        command = lambda ch=char: press(ch)

    tk.Button(root, text=char, font=("Arial", 14), bg=color, command=command)\
        .grid(row=r, column=c, columnspan=cs, rowspan=rs, sticky="nsew", padx=2, pady=2)

root.mainloop()
