# write data in csv 
import csv

dict = [{'Name': 'John', 'Age': 28, 'City': 'New York'},
        {'Name': 'Anna', 'Age': 22, 'City': 'London'},
        {'Name': 'Mike', 'Age': 32, 'City': 'San Francisco'}]


with open('people.csv', mode='w', newline='') as file:
    writer = csv.writer(file)
    for i in dict:
        writer.writerow(i.values())

print("Data written to people.csv successfully.")
print("\n")

# now read data from csv file

try : 
    read = csv.reader(open('people.csv', mode='r'))
    for row in read:
        print(row)

except Exception as e:
    print("Error occurred while reading the file:", e)
    
