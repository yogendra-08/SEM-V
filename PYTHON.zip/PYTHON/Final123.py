import pandas as pd 
import numpy as np

data = {
    "name" : ['yogi','yash','anuj'],
    "age" : [18,17,20],
    "city" : ['Nagpur', 'Saoner', 'Amravati']
}

df = pd.DataFrame(data)

print("Original DataFrame : \n")
print(df)

print("\n ------------------ \n")

df_sort = df.sort_values(by = "age")

print("DataFrame after sorting by age : \n")
print(df_sort)


df_sortbyname = df.sort_values(by = "name" , ascending=False)
print("DataFrame after sorting by name (descending) : \n")
print(df_sortbyname)

print("\n ------------------ \n")

data1 = {
    "name" : ['yogi','yash','anuj'],
    "age" : [18,np.nan,20],
    "city" : ['Nagpur', 'Saoner', 'Amravati']
}

df = pd.DataFrame(data1)

print("Dataframe with NULL value: \n")
print(df)
print("\n")

df_drop = df.dropna()
print("DataFrame after dropping rows with NaN values : \n")
print(df_drop)


df_fill = df.fillna(
    {
        "name" : "unknown",
        "age" : 19 ,
        "city" : "unknown",
    }
)

print("\n")
print("DataFrame after filling NaN values : \n")
print(df_fill)
