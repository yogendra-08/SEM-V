import tkinter as tk
from tkinter import messagebox

window = tk.Tk()
window.geometry("400x250")
window.title("Login Form")
window.config(bg="lavender")

def login():
    username = entry1.get()
    password = entry2.get()
    
    if username == "admin" and password == "0808":
        messagebox.showinfo("Login Success", "Welcome!")
    else:
        messagebox.showerror("Login Failed", "Invalid Username or Password")


label1 = tk.Label(window, text="Simple Login Form", fg="blue", font=("Helvetica", 16, "bold"), bg="lavender")
label1.grid(row=0, column=0, columnspan=2, pady=15)


label2 = tk.Label(window, text="Username:", fg="black", font=("Helvetica", 12), bg="lavender")
label2.grid(row=1, column=0, padx=10, pady=10, sticky="e")

entry1 = tk.Entry(window, font=("Helvetica", 12))
entry1.grid(row=1, column=1, padx=10, pady=10)


label3 = tk.Label(window, text="Password:", fg="black", font=("Helvetica", 12), bg="lavender")
label3.grid(row=2, column=0, padx=10, pady=10, sticky="e")

entry2 = tk.Entry(window, show="*", font=("Helvetica", 12))
entry2.grid(row=2, column=1, padx=10, pady=10)


button = tk.Button(window, text="Login", bg="green", fg="white", font=("Helvetica", 12, "bold"), width=12, command=login)
button.grid(row=3, column=0, columnspan=2, pady=20)

window.mainloop()
