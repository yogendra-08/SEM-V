import cmath
import random


print("\n")
a = input("Enter a complex number (a+bi): ")
complex_num = complex(a) # convert input into complex number 

print("Sine:", cmath.sin(complex_num))
print("Cosine:", cmath.cos(complex_num))
print("Tangent:", cmath.tan(complex_num))

print("\n")
num1 = int(input("Enter the starting number: "))
num2 = int(input("Enter the ending number: "))

random_num = random.randint(num1, num2)
print("Random integer between", num1, "and", num2, "is:", random_num)
 