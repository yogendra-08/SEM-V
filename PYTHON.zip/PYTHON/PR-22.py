import io 

def stringio_demo():

    text = io.StringIO()
    
    
    text.write("Hello, World!\n")
    text.write("This is a StringIO example.\n")
    text.write("You can write and read strings in memory.\n")

    
    text.seek(0)  
    content = text.read()
    print(content)

     
    text.close()

if __name__ == "__main__":
    stringio_demo()