import string 

str = "Yash"
print("\nEntered string is:", str)

x = str.isalpha()
print("\nString contains only characters.", x) 

y = str.isdigit()
print("\nString contains only digits.", y)

z = str.isalnum()
print("\nString contains only alphanumeric characters.", z,"\n") 


#prac 17

str_t = "2307023"

x = str_t.isdigit()

if x:
    print("\nString contains only digits.", x)

else:
    print("\nString contains characters and numbers.", x)


#prac18

str = "Hello Yash"
print("\nEntered string is:", str)

x = str.upper()
print("\nUppercase of the string is:", x)

y = str.lower()
print("\nLowercase of the string is:", y,"\n")


#prac19

str = " "
print("\nEntered string is:", str)

x = str.isspace()
print("\nString contains only spaces.", x,"\n")

str = "\n\t"

y = all( ch in string.whitespace for ch in str )
print("String contains only whitespaces.", y,"\n")

print(repr(string.whitespace))