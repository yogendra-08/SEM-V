import tkinter as tk

window = tk.Tk()
window.geometry("300x200")


b = tk.Label(window, text="Hello world", bg = "purple", fg="white")
b.pack(pady=50)

window.mainloop()
