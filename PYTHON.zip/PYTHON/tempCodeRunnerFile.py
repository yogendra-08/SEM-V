root = tk.Tk()
root.title("Simple Calculator")
root.geometry("300x500")
root.config(bg="lightblue")