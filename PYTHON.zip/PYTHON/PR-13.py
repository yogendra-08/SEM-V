import tkinter as tk

root = tk.Tk()
root.title("Stopwatch")
root.geometry("500x500")
root.config(bg="lavender")

running = False
counter = 0

def count():
    global counter
    if running:
        if counter == 0:
            display = "Starting..."
        else:
            display = f"{counter:02d}"  
        label.config(text=display)
        counter += 1
        label.after(1000, count)  

def start():
    global running
    running = True
    start_btn.config(state="disabled")
    stop_btn.config(state="normal")
    reset_btn.config(state="normal")
    count()

def stop():
    global running
    running = False
    start_btn.config(state="normal")
    stop_btn.config(state="disabled")
    reset_btn.config(state="normal")

def reset():
    global counter, running
    running = False
    counter = 0
    label.config(text="00")  
    start_btn.config(state="normal")
    stop_btn.config(state="disabled")
    reset_btn.config(state="disabled")

label = tk.Label(root, text="00", font=("Helvetica", 48), bg="black", fg="white")
label.pack(pady=20)

start_btn = tk.Button(root, text="Start", font=("Helvetica", 24), bg="white", fg="black", command=start)
start_btn.pack(padx=10)

stop_btn = tk.Button(root, text="Stop", font=("Helvetica", 24), bg="white", fg="black", state="disabled", command=stop)
stop_btn.pack(padx=10)

reset_btn = tk.Button(root, text="Reset", font=("Helvetica", 24), bg="white", fg="black", state="disabled", command=reset)
reset_btn.pack(padx=10)

root.mainloop()
