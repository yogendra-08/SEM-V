import pickle 

data = {'name': 'Alice', 'age': 30, 'city': 'New York'}

with open('data.pkl', 'wb') as file:
    pickle.dump(data, file)
print("Data has been serialized and saved to data.pkl\n")

#Load the data from the file
with open('data.pkl', 'rb') as file:
    loaded_data = pickle.load(file)

print(loaded_data)

# serializing -> to convert python object into byte stream 
# deserializing -> to convert byte stream back into python object

# the pickle module in python is used for serializing and deserializing python object structures.
# that is pickling and unpickling.

# stream is flow of data  

