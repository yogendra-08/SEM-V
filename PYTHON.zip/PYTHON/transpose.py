import numpy as np

A = np.array([[1, 2, 3],
              [4, 5, 6],
              [7, 8, 9]])

print("Original matrix:")
print(A)
print("\n")

A_transpose = np.transpose(A)
print("Transpose of matrix:")
print(A_transpose)
