import statistics as st
import numpy as np

data = [10,30,50,20,40]

print("\n")
print("original")
print(data)
print("\n")

print("Mean : ", np.mean(data))
print("Median : ", st.median(data))

mode  = st.mode(data)
print("Mode:", mode)

