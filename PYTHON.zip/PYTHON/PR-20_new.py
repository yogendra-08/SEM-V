#Develop a program to find the square root of a number using math.sqrt()
#& compute the factorial of a number using math.factorial().

import math

num = int(input("Enter a number: "))
sqrt = math.sqrt(num)
print("Square root of", num, "is", sqrt)

fact = math.factorial(num)

print("Factorial of", num, "is", fact)
