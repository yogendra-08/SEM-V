import time
import sys
from playsound import playsound
import threading

# Function to type lyrics slowly
def type_lyric(line, char_delay=0.065):
    for char in line:
        print(char, end='', flush=True)
        time.sleep(char_delay)
    print()

# Function to print lyrics line by line
def print_lyrics():
    lyrics = [
        "Arz kiya hai",
        "Humne bhi likha kuch tere baare mein",
        "Haathon ko sambhaale mere haathon mein",
        "Kaise haathon ko sambhaale mere haathon mein?",
        "Jab tak neend na aaye in lakeeron mein",
        "Baatein hon...",
        "Haan...",
    ]

    delays = [2.0, 1.3, 1.8, 2.1, 2.4, 1.7, 1.5]

    print("\n🎵 Arz Kiya Hai - Lyrics 🎶\n")
    time.sleep(1.5)

    for i, line in enumerate(lyrics):
        type_lyric(line)
        time.sleep(delays[i])


def play_song():
    
    playsound("T:\PYTHON\A_PVT\ARZ_KIYA_HAI_2.mp3")

song_thread = threading.Thread(target=play_song)
song_thread.start()

print_lyrics()


song_thread.join()
