import tkinter as tk
import random
import math
import time
import threading
import pygame  # for music (pip install pygame)

# Initialize pygame mixer for background music
pygame.mixer.init()

# Load and play birthday song (replace with path to your mp3)
try:
    pygame.mixer.music.load("happy-birthday.mp3")
    pygame.mixer.music.play(-1)  
except:
    print("Music file not found! Place 'happy-birthday.mp3' in the same folder.")


root = tk.Tk()
root.title("🎂 Happy Birthday 🎂")
root.geometry("800x600")
root.config(bg="black")


canvas = tk.Canvas(root, width=800, height=600, highlightthickness=0)
canvas.pack(fill="both", expand=True)

balloons = []
confetti = []
text_size = 30
text_increasing = True


def draw_gradient():
    for i in range(0, 600):
        color = "#%02x%02x%02x" % (255, 180 - i//4, 200 - i//6)
        canvas.create_line(0, i, 800, i, fill=color)


def create_balloon():
    x = random.randint(50, 750)
    y = 600
    r = random.randint(20, 40)
    color = random.choice(["red", "blue", "green", "orange", "pink", "purple", "yellow"])
    balloon = canvas.create_oval(x-r, y-r, x+r, y+r, fill=color, outline="black")
    string = canvas.create_line(x, y+r, x, y+r+40, fill="black", width=2)
    balloons.append((balloon, string, random.randint(1, 3)))


def animate_balloons():
    for balloon, string, speed in balloons:
        canvas.move(balloon, 0, -speed)
        canvas.move(string, 0, -speed)
        x1, y1, x2, y2 = canvas.coords(balloon)
        if y2 < 0:
            canvas.move(balloon, 0, 650)
            canvas.move(string, 0, 650)
    root.after(50, animate_balloons)


def create_confetti():
    x = random.randint(0, 800)
    y = 0
    size = random.randint(3, 8)
    color = random.choice(["red", "blue", "green", "yellow", "purple", "pink", "orange"])
    dot = canvas.create_oval(x, y, x+size, y+size, fill=color, outline="")
    confetti.append((dot, random.randint(2, 6)))

def animate_confetti():
    for dot, speed in confetti:
        canvas.move(dot, 0, speed)
        x1, y1, x2, y2 = canvas.coords(dot)
        if y1 > 600:
            canvas.move(dot, 0, -650)
    root.after(50, animate_confetti)

def animate_text():
    global text_size, text_increasing
    canvas.delete("title")
    font = ("Comic Sans MS", text_size, "bold")
    canvas.create_text(400, 100, text="🎉 Happiest Birthday Mam 🎉",
                       font=font, fill=random.choice(["white", "gold", "pink"]),
                       tags="title")
    if text_increasing:
        text_size += 2
        if text_size > 50:
            text_increasing = False
    else:
        text_size -= 2
        if text_size < 30:
            text_increasing = True
    root.after(150, animate_text)


def generate_balloons():
    create_balloon()
    root.after(1200, generate_balloons)

def generate_confetti():
    create_confetti()
    root.after(200, generate_confetti)


draw_gradient()


generate_balloons()
animate_balloons()
generate_confetti()
animate_confetti()
animate_text()


canvas.create_text(790, 580, text="- YOGI", anchor="se",
                   font=("Helvetica", 14, "bold"), fill="white")

root.mainloop()
