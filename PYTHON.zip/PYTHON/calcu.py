import tkinter as tk
from tkinter import messagebox
import math

Window = tk.Tk()
Window.geometry("300x400")
Window.config(bg="lightblue")
Window.title("Simple Calculator")

Window.mainloop()


