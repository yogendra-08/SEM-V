import numpy as np
from scipy import linalg

A = np.array([[7, 4],
              [2, 3]])

print("Original matrix:")
print(A)
print("\n") 


try:
    A_inv = linalg.inv(A)
    print("Inverse of matrix:")
    print(A_inv)
    print("\n") 

    
    identity = np.dot(A, A_inv)
    print("Identity matrix (A * A_inv):")
    print(identity)
    print("\n")

except linalg.LinAlgError:
    print("Matrix is singular and cannot be inverted.")
