import tkinter as tk
import tkinter.messagebox as mb

root = tk.Tk()
root.title("Registration Form")
root.geometry("400x500")
root.resizable(False, False)
root.configure(bg="lavender")

def submit():
    name = name_entry.get()
    email = email_entry.get()
    password = password_entry.get()
    gender = gendervar.get()
    country = countryvar.get()

    result_label.config(
        text=f"Name: {name}\nEmail: {email}\nPassword: {password}\nGender: {gender}\nCountry: {country}"
    )

def register():
    mb.showinfo("Registration", "Registration Successful!")

# Heading
tk.Label(root, text="Registration Form", bg="white", fg="red").grid(row=0, column=0, columnspan=2, pady=15)

# Name
tk.Label(root, text="Name:", bg="white").grid(row=1, column=0, padx=10, pady=10, sticky="e")
name_entry = tk.Entry(root, width=25)
name_entry.grid(row=1, column=1, pady=10)

# Email
tk.Label(root, text="Email:", bg="white").grid(row=2, column=0, padx=10, pady=10, sticky="e")
email_entry = tk.Entry(root, width=25)
email_entry.grid(row=2, column=1, pady=10)

# Password
tk.Label(root, text="Password:", bg="white").grid(row=3, column=0, padx=10, pady=10, sticky="e")
password_entry = tk.Entry(root, width=25, show="*")
password_entry.grid(row=3, column=1, pady=10)

# Gender
tk.Label(root, text="Gender:", bg="white").grid(row=4, column=0, padx=10, pady=10, sticky="e")
gendervar = tk.StringVar(value="Male")
tk.Radiobutton(root, text="Male", variable=gendervar, value="Male", bg="white").grid(row=4, column=1, sticky="w")
tk.Radiobutton(root, text="Female", variable=gendervar, value="Female", bg="white").grid(row=4, column=1, sticky="e")

# Country
tk.Label(root, text="Country:", bg="white").grid(row=5, column=0, padx=10, pady=10, sticky="e")
countryvar = tk.StringVar(value="India")
tk.OptionMenu(root, countryvar, "India", "USA", "UK", "Canada", "Australia").grid(row=5, column=1, pady=10)

# Buttons
tk.Button(root, text="Submit", bg="teal", fg="white", width=10, command=submit).grid(row=6, column=0, pady=15)
tk.Button(root, text="Register", bg="green", fg="white", width=10, command=register).grid(row=6, column=1, pady=15)

# Result Label
result_label = tk.Label(root, text="", bg="white", justify="left")
result_label.grid(row=7, column=0, columnspan=2, pady=20)

root.mainloop()
