import tkinter as tk
import tkinter.messagebox as mb
import re

root = tk.Tk()
root.title("Registration Form")
root.geometry("500x600")
root.resizable(False, False)
root.configure(bg="lavender")


def submit():
    name = name_entry.get()
    email = email_entry.get()
    phone = phone_entry.get()
    password = password_entry.get()
    gender = gendervar.get()
    country = countryvar.get()

    result_label.config(
        text=f"Name: {name}\nEmail: {email}\nPhone: {phone} \nPassword: {password}\nGender: {gender}\nCountry: {country}",
        fg="black",
        font=("Helvetica", 12),
        justify="left",
        bg="white"
    )

def register():
    name = name_entry.get()
    email = email_entry.get()
    phone = phone_entry.get()
    password = password_entry.get()
    gender = gendervar.get()
    country = countryvar.get()

    
    if not name or not email or not password or not gender or not country:
        mb.showerror("Error", "All fields are required!")
        return  

   
    if not is_valid_email(email):
        mb.showerror("Error", "Invalid Email Address!")
        return  
    
    if not is_valid_phone(phone):
        mb.showerror("Error", "Invalid Phone Number!")
        return

    
    mb.showinfo("Registration", "Registration Successful!")


def is_valid_email(email):
    return re.match(r"[^@]+@[^@]+\.[^@]+", email) is not None

def is_valid_phone(phone):
    return re.match(r"^\d{10}$", phone) is not None


# Heading
heading = tk.Label(root, text="Registration Form", font=("Helvetica", 28, "bold"), bg="white", fg="red")
heading.grid(row=0, column=0, columnspan=2, pady=20)

# Name
tk.Label(root, text="Name:", font=("Helvetica", 16), bg="white").grid(row=1, column=0, sticky="e", padx=10, pady=10)
name_entry = tk.Entry(root, font=("Helvetica", 16), width=25)
name_entry.grid(row=1, column=1, pady=10)

# Email
tk.Label(root, text="Email:", font=("Helvetica", 16), bg="white").grid(row=2, column=0, sticky="e", padx=10, pady=10)
email_entry = tk.Entry(root, font=("Helvetica", 16), width=25)
email_entry.grid(row=2, column=1, pady=10)

# Phone
tk.Label(root, text="Phone:", font=("Helvetica", 16), bg="white").grid(row=3, column=0, sticky="e", padx=10, pady=10)
phone_entry = tk.Entry(root, font=("Helvetica", 16), width=25)
phone_entry.grid(row=3, column=1, pady=10)

# Password
tk.Label(root, text="Password:", font=("Helvetica", 16), bg="white").grid(row=4, column=0, sticky="e", padx=10, pady=10)
password_entry = tk.Entry(root, font=("Helvetica", 16), width=25, show="*")
password_entry.grid(row=4, column=1, pady=10)

# Gender
tk.Label(root, text="Gender:", font=("Helvetica", 16), bg="white").grid(row=5, column=0, sticky="e", padx=10, pady=10)
gendervar = tk.StringVar(value="Male")
gender_frame = tk.Frame(root, bg="white")
gender_frame.grid(row=5, column=1, pady=10, sticky="w")
tk.Radiobutton(gender_frame, text="Male", variable=gendervar, value="Male", font=("Helvetica", 14), bg="white").pack(side="left", padx=5)
tk.Radiobutton(gender_frame, text="Female", variable=gendervar, value="Female", font=("Helvetica", 14), bg="white").pack(side="left", padx=5)

# Country
tk.Label(root, text="Country:", font=("Helvetica", 16), bg="white").grid(row=6, column=0, sticky="e", padx=10, pady=10)
countryvar = tk.StringVar(value="India")
country_menu = tk.OptionMenu(root, countryvar, "India", "USA", "UK", "Canada", "Australia")
country_menu.config(font=("Helvetica", 14), width=20)
country_menu.grid(row=6, column=1, pady=10)

# Buttons
submit_btn = tk.Button(root, text="Submit", font=("Helvetica", 16, "bold"), bg="Teal", fg="white", width=12, command=submit)
submit_btn.grid(row=7, column=0, pady=20)

register_btn = tk.Button(root, text="Register", font=("Helvetica", 16, "bold"), bg="green", fg="white", width=12, command=register)
register_btn.grid(row=7, column=1, pady=20)

# Result label
result_label = tk.Label(root, text="", font=("Helvetica", 12), fg="black", bg="white", justify="left")
result_label.grid(row=8, column=0, columnspan=2, pady=20)

root.mainloop()
