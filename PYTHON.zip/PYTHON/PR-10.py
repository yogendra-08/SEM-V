import tkinter as tk
from tkinter import messagebox

window = tk.Tk()
window.geometry("300x200")

def show_message():
    messagebox.showinfo("Message", "Hello World")

b = tk.Button(window, text="Display Message", bg = "pink", command=show_message)
b.pack(pady=50)

window.mainloop()
