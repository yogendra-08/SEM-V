import pandas as pd 

data1 = {
    "id" : [1,2,3,4],
    "name" : ["Alice", "Bob", "Charlie","David"],
    "dept" : ['HR','IT','Finance','HR']
}

df_A = pd.DataFrame(data1)

print("First DataFrame : \n")
print(df_A)
print("\n")

data2 = {
    "id" : [1,3,5,6],
    "Salary" : [60000,75000,80000,55000],
    "yrs_exp" : [5,8,3,2]
}

df_B = pd.DataFrame(data2)

print("Second DataFrame : \n")
print(df_B)
print("\n")

df_merge = df_A.merge(df_B)
print("DataFrame after merging : \n")
print(df_merge)
print("\n")

df_mergeleft = df_A.merge(df_B, how='left')
print("DataFrame after merging (left) : \n")
print(df_mergeleft)
print("\n")

df_mergeright = df_A.merge(df_B, how='right')
print("DataFrame after merging (right) : \n")
print(df_mergeright)
print("\n")

df_mergeinner = df_A.merge(df_B, how='inner')
print("DataFrame after merging (inner) : \n")
print(df_mergeinner)
print("\n")

df_mergeouter = df_A.merge(df_B, how='outer')
print("DataFrame after merging (outer) : \n")
print(df_mergeouter)
print("\n")