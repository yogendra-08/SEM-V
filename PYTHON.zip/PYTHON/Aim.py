# To check weather giving string contaion only charcter or not 

import re 

str = "hello"

